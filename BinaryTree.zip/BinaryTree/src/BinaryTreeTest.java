
public class BinaryTreeTest<E> {
	public static void main(String[] args) {
		// Create the tree shown in the video:
		BinaryTree<String> myTree = new BinaryTree<String>();
		Position<String> pat = myTree.addRoot("Pat");
		Position<String> chris = myTree.addLeft(pat, "Chris");
//		Position<String> sam = myTree.addRight(pat, "Sam");
		myTree.addLeft(chris, "Jordan");
//		myTree.addRight(chris, "Casey");
//		Position<String> charlie = myTree.addRight(sam, "Charlie");
//		Position<String> drew = myTree.addLeft(charlie, "Drew");
		System.out.println(myTree);
	}
	
	public String printAncestors(BinaryTree<String> myTree, Position<String> pos) {
		
		
		String output = "";
		while(pos != null) {
			output += pos;
			pos = myTree.getParent(pos);
			
		}
		
		return output;
	}
}