
public interface Position<E> {
	E getValue();
}
