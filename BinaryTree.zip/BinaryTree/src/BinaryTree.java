

public class BinaryTree<E> {
	private Node root;
	private int size;
	public BinaryTree() {
		root = null;
		size = 0;
	}
	public Position<E> addRoot(E v) {
		if (root != null) {
            throw new IllegalStateException("BinaryTree: addRoot called when root already exists.");
		}
		root = new Node(v, null, null, null);
		size++;
		return root;
	}
	public Position<E> getRoot() {
		return root;
	}
	
	public int nodeDepth(Position<E> node) {
		Node Node = validatePosition(node);
		int depth = 0;//
		while(Node != null) {
			//depth++;
			Node = Node.parent;
		}
		return depth;
	}
	
	public int recursiveNodeDepth(Node node) {
		
		if(node == null) {
			return -1;
		}
		return 1+  recursiveNodeDepth(node.parent);
	}
	// confirm validity of p by checking it is a node and casting it to a node
	private Node validatePosition(Position<E> p) {
		if (p==null) {
			throw new IllegalStateException("BinaryTree: Position passed is not valid");
		} else if (!(p instanceof BinaryTree.Node)) {
            throw new IllegalStateException("BinaryTree: Position passed is not a Node of BinaryTree");			
		}
		return (Node) p;
	}
	public Position<E> addLeft(Position<E> parent, E value) {
		Node p = validatePosition(parent);
		if (p.leftChild != null) {
            throw new IllegalStateException("BinaryTree: addLeft called when left child already exists.");			
		}
		p.leftChild = new Node(value, p, null, null);
		size++;
		return p.leftChild;
	}
	
	public Position<E> getleft(Position<E> p) {
		Node n = validatePosition(p);
		return n.leftChild;
	}
	
	public Position<E> getRight(Position<E> p) {
		Node n = validatePosition(p);
		return n.rightChild;
	}
	
	public Position<E> getParent(Position<E> p) {
		Node n = validatePosition(p);
		return n.parent;
	}
	
	
	private String toStringRecursive(Node startingNode, int depth, StringBuilder sb) {
		for (int i = 0; i < depth; i++) {
			sb.append("\t"); // depending on the depth, add a the appropriate number of tabs
		}
		sb.append(startingNode.toString() + "\n"); // append the value of this root node
		if (startingNode.leftChild != null) { // if the left child exists
			// recursively call this method for the left subtree
			toStringRecursive(startingNode.leftChild, depth+1,sb);
		}
		if (startingNode.rightChild != null) { // if the right child exists
			// recursively call this method for the right subtree
			toStringRecursive(startingNode.rightChild, depth+1, sb);
		}
		// return the String that has been built so far
		return sb.toString();
	}
	@Override
	public String toString() {
		return toStringRecursive(root, 0, new StringBuilder());
	}
	
	private class Node implements Position<E> {
        private Node parent;
        private Node leftChild;
        private Node rightChild;
        private E value;
        public Node(E v, Node p, Node l, Node r) {
        	value = v;
        	parent = p;
        	leftChild = l;
        	rightChild = r;
        }
        public String toString() {
        	return value.toString();
        }
        public E getValue() {
        	return value;
        }
	}
}
