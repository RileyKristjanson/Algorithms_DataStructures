package kristjanson;

import java.util.ArrayList;
import java.util.Iterator;

public class TreeSet<E extends Comparable<E>> implements Set<E> 
{
	private Node root;
	private int size;
	public TreeSet()
	{
		root = null;
		size = 0;
	}
	/**
	 * 
	 * @param values - the array to load up with values in the tree
	 * @param r - node to start with as the root node of the subtree
	 */
	private void populateSnapshot(ArrayList<E> values, Node r) {
		//base case
		if(r == null) {
			return;
		}
		//inorder traversal
		populateSnapshot(values, r.leftChild);	
		values.add(r.value);
	}
	
	public void printSorted() {
		printSorted(root);
	}
	
	//In order traversal
	public void printSorted(Node n) {
		if(n == null) {
			return;
		}
		if(n.leftChild != null) {
			printSorted(n.leftChild);
		} 
		System.out.print(n.toString() + " ");
		
		if (n.rightChild != null) {
			printSorted(n.rightChild);
		}
			
	}
	
	
	@Override
	public Iterator<E> iterator() 
	{
		ArrayList<E> snapshot = new ArrayList<E>();
		
		populateSnapshot(snapshot, root);
		return snapshot.iterator();
	}
	private Node add(Node r, E e)
	{
		if(r == null)
		{
			size++;
			return new Node(e);
		}
		else if(r.value.compareTo(e) < 0)
		{
			r.rightChild = add(r.rightChild, e);
		}
		else if(r.value.compareTo(e) > 0)
		{
			r.leftChild = add(r.leftChild, e);
		}
		return r;
	}
	@Override
	public boolean add(E e) {
		int oldSize = size;
		this.root = add(this.root, e);
		return oldSize < size;
	}
	/** 
	 * Recursive method that removes the value e from the tree rooted at r
	 * @param r
	 * @param e
	 * @return
	 */
	
	private Node remove(Node r, E e)
	{
		//We didn't find the value
		if(r == null)
		{
			return null;
		}
		else if(r.value.compareTo(e) < 0)
		{
			r.rightChild = remove(r.rightChild, e);
		}
		else if(r.value.compareTo(e) > 0)
		{
			r.leftChild = remove(r.leftChild, e);
		}
		else //we found the node that we are supposed to return
		{
			//Node we are removing is leaf or has rightChild only
			if(r.leftChild == null)
			{
				size--;
				return r.rightChild;
			}
			else if(r.rightChild == null)
			{
				size--;
				return r.leftChild;
			}
			//Case 3: Node has two children
			else
			{
				//find predecessor
				Node pred = r.leftChild;
				while(pred.rightChild != null)
				{
					pred = pred.rightChild;
				}
				r.value = pred.value;
				r.leftChild = remove(r.leftChild, pred.value);
			}
		}
		return r;
	}
	@Override
	public boolean remove(E e) 
	{
		int oldSize = this.size;
		this.root = remove(this.root, e);
		return size < oldSize;
	}
	
	private int containsHelper(Node n, E e) {
		
		if(n == null) {
			return 0;
		}
		if(n.value == e) {
			return 1;
		}
		if(n.value.compareTo(e) < 0l) {
			containsHelper(n.leftChild, e);
		}
		if(n.value.compareTo(e) > 0) {
			containsHelper(n.rightChild, e);
		} 
		
		return 0;
		
		
	}
	@Override
	public boolean contains(E e) {
		
		return (containsHelper(root, e) == 1);
	}
	@Override
	public void addAll(Set<E> T) {
		for (E e : T) {
			add(e);
		}
	}
	@Override
	public void retainAll(Set<E> T) {
		Iterator<E> iter = this.iterator();
		
		while (iter.hasNext()) {
			if (!T.contains(iter.next())) {
				iter.remove();
			}
		}
	}
	@Override
	public void removeAll(Set<E> T) {
		Iterator<E> it = this.iterator();
		while (it.hasNext()) {
			remove(it.next());
		}
	}
	private void toString(Node r, StringBuilder sb, int level)
	{
		if(r != null)
		{
			//Print the root
			for(int i=0; i < 2 * level; i++)
			{
				sb.append(" ");
			}
			//Recursively print the left and right children
			sb.append(r.toString() + "\n");
			toString(r.leftChild, sb, level+1);
			toString(r.rightChild, sb, level+1);
		}
	}
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		toString(root, sb, 0);
		String r = sb.toString();
		return r;
	}
	//Node class
	private class Node
	{
		private E value;
		private Node leftChild;
		private Node rightChild;
		public Node(E v)
		{
			this.value = v;
			this.leftChild = null;
			this.rightChild = null;
		}
		public String toString()
		{
			return value.toString();
		}
	}
	
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}
	
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return size == 0;
	}
}
