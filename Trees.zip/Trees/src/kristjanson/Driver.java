package kristjanson;

import java.util.Iterator;
import java.util.Scanner;
public class Driver 
{
	public static void main(String[] args)
	{
		
		TreeSet<Integer> tree = new TreeSet<>();
		TreeSet<Integer> test = new TreeSet<>();
		for(int i=0; i < 10; i++)
		{
			tree.add((int)(Math.random() * 1000));
		}
		
		Iterator<Integer> it = tree.iterator();
		while(it.hasNext())
		{
			System.out.print(it.next() + " ");
		}
		tree.add(100);
		test.add(100);
		tree.printSorted();
		System.out.println(test.contains(100));
		test.addAll(tree);
		test.printSorted();
		test.removeAll(test);
		//test.printSorted();
		
		/*
		while(true)
		{
			System.out.println("Pick a value to remove:");
			Scanner input = new Scanner(System.in);
			int value = input.nextInt();
			tree.remove(value);
			System.out.println(tree + "\nsize: " + tree.size());
		}*/
	}
}
