package kristjanson;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DynamicArray<T> implements List<T>, Iterable<T> {
	private int size;
	protected T[] data;
	private int numExpansions;
	private static final int STARTING_CAPACITY = 16;
	public DynamicArray() {
		this(STARTING_CAPACITY);
	}
	public DynamicArray(int capacity) {
		size = 0;
		numExpansions = 0;
		data = (T[]) new Object[capacity];		
	}
	@Override
	public int size() {
		return size;
	}
	@Override
	public boolean isEmpty() {
		return size==0;
	}
	@Override
	public T get(int index) {
		// check for validity of the index
		checkIndex(index, size);
		return data[index];
	}
	@Override
	public T set(T element, int index) {
		checkIndex(index, size);
		T oldValue = data[index];
		data[index] = element;
		return oldValue;
	}
	@Override
	public void add(int index, T element) {
		checkIndex(index, size+1);
		// expand the array if the array is already full
		if (size == data.length) {
			expandArray();
		}
		// shift elements down
		for (int i=size-1; i>=index   ;i--) {
			data[i+1] = data[i];
		}
		// store new element in the correct spot:
		data[index] = element;
		size++;
	}
	
	@Override
	public T remove(int index) {
		T remove = data[index];
		T[] result = (T[]) new Object[data.length - 1];
		for (int i = 0; i < index; i++) {
			result[i] = data[i];
		}
		for (int i = index; i < data.length - 1; i++) {
			result[i] = data[i + 1];
		}
		
		data=result;
		size--;
		return remove;
	}
	
	protected void expandArray() {
		// create a new array, twice as large
		// array is growing geometrically (also called exponentially)
		T[] newData = (T[]) new Object[2*data.length];
		// copy old array contents into new array contents
		for (int i = 0; i < data.length; i++) {
			newData[i] = data[i];
		}
		data = newData;
		numExpansions++;		
	}
	private void checkIndex(int index, int limit) {
		if (index<0 || index >= limit) {
			throw new IndexOutOfBoundsException(
					"DynamicArray: index " + index + " invalid for dynamic array of size " + size);
		}
	}
	
	public String toString() {
		String s = "List Contents: ";
		for(int i = 0; i < size; i++) {
			s += (data[i] + " ");
		}
		
		return s;
	}
	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new ArrayIterator();
	}
	
	private class ArrayIterator implements Iterator<T> {
		private int current;
		private boolean canRemove = true;
		private ArrayIterator() {
			current = 0;
			
		}

		@Override
		public boolean hasNext() {
			if (current != size) {
				canRemove = true;
				return true;
			}
			canRemove = false;
			return false;
		}

		@Override
		public T next() {
			if (!hasNext()) {
				throw new NoSuchElementException("ArrayIterator: next() called when there is no next node");
			}
			T returnValue = data[current];
			current++;
			canRemove = true;
			return returnValue;
		}
		
		public void remove() {
			if(canRemove) {
				DynamicArray.this.remove(current);
			}
		}
	}
}   