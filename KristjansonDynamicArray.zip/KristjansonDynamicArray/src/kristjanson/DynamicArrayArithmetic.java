package kristjanson;

public class DynamicArrayArithmetic extends DynamicArray{

	public DynamicArrayArithmetic() {
		super();
	}
	
	@Override
	protected void expandArray() {
		
	}
}
