package kristjanson;

public interface List<T> {
	   // @return current size of array
	   int size();
	   // @return boolean, true if list has no element, false otherwise
	   boolean isEmpty();
	   // @return the element at index i. 
	   // IndexOutOfBoundsException if i is not a valid index
	   T get(int i);
	   // @return the element at index i that was replaced by the parameter 
	   // IndexOutOfBoundsException if i is not a valid index
	   T set(T element, int index);
	   // @param index, index at which to insert element; elements below it are shifted down
	   // @param element, give value of element to store in position i
	   void add(int index, T element);
	   // @param index, gives position of element to remove; elements below it are shifted up
	   // @ return value of element that was removed
	   T remove(int index);
}
