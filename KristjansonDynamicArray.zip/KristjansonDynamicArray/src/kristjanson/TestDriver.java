package kristjanson;

import java.util.Iterator;

public class TestDriver {

	public static void main(String[] args) {
		
		DynamicArray<Integer> array = new DynamicArray<Integer>();
		
		for(int i = 0; i < 100; i++) {
			array.add(i, i+1);
		}
		
		Iterator<Integer> iter = array.iterator();
		int total = 0;
		while(iter.hasNext()) {
			total += iter.next();
		}
		System.out.println(array.toString());
		System.out.println(total);
		
		Iterator<Integer> iter1 = array.iterator();
		total = 0;
		for(int i = 0; i < 50; i++) {
			iter1.remove();
			
		}
		
		for(int i: array) {
			total += iter1.next();
		}
		System.out.println(array.toString());
		System.out.println(total);
	}
}
