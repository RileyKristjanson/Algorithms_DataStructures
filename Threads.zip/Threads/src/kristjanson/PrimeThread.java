package kristjanson;

public class PrimeThread implements Runnable{

	private int start;
	private int stop;
	private int num;
	
	public PrimeThread(int n, int s, int st) {
		this.num = n;
		this.start = s;
		this.stop = st;
		
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		PrimeFinder pnf = new PrimeFinder();
		
		System.out.println("Thread: " + num + " : " + start +
				" - " + stop + " there are " + 
				pnf.primeRange(start, stop) + " Prime numbers");
	}
	
	
}
