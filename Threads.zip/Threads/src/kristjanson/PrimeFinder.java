package kristjanson;

public class PrimeFinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int min = 10;
		int max = 110;
		
		int n = max - min;
		int numThreads = 4;
		
		Thread[] ths = new Thread[numThreads];
		int[] a = new int[numThreads];
		
		for(int i = 0; i < numThreads; i++) {
			int start = (n/numThreads) * i;
			int stop = (n/numThreads) * (i+1);
			
			PrimeThread pt = new PrimeThread(i, start, stop);
			
			Thread th = new Thread(pt);
			ths[i] = th;
			th.start();
		}
		
		for(int i = 0; i < numThreads; i++) {
			try {
				ths[i].join();
				
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	public static boolean isPrime(int n) {
		int i = 2;
		boolean prime = true;
		
		if(n < 2) {
			prime = false;
		}
		
		while(i < n && prime) {
			if((n%i) == 0) {
				prime = false;
			}
			i++;
		}
		return prime;
	}
	
	public static int primeRange(int start, int stop) {
		
		int primeNums = 0;
		
		for(int i = start; i <= stop; i++) {
			if(isPrime(i)) {
				primeNums++;
			}
		}
		return primeNums;
	}

}
