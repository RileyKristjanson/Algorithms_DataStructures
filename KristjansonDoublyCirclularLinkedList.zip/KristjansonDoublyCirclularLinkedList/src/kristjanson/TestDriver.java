package kristjanson;

public class TestDriver {

	public static void main(String[] args) {
		CircularDoublyLinkedList<Integer> testList = new CircularDoublyLinkedList<Integer>();
		
		testList.addAfterCursor(10);
		testList.addAfterCursor(20);
		testList.addAfterCursor(30);
		testList.addAfterCursor(50);
		
		System.out.println(testList.toString());
		while (!testList.isEmpty()) {
			System.out.println(testList.deleteCursor());
		}
		System.out.println(testList.toString());

	}

}
