package kristjanson;

public class CircularDoublyLinkedList<T> {
	private Node cursor;
	private int size;
	
	public CircularDoublyLinkedList() {
		cursor = null;		
		size = 0;
	}
	
	// advance cursor forward one node
	public void advance() {
		// don't change the contents of the list
		// but move the cursor forward one node
		cursor = cursor.next;
	}
	
	public void advanceCursor(int n) {
		for(int i = 0; i < n; i++) {
			
			cursor = cursor.next;
		}
	}
	
	public void addAfterCursor(T value)
	{
		Node newNode = new Node(value);
		
		if(cursor == null) {
			cursor = newNode;
			cursor.next = cursor;
			cursor.prev = cursor;
			size++;
		} else {
        newNode.next = cursor.next;
        newNode.prev = cursor;
		cursor.next = newNode;
		size++;
		newNode.next.prev = newNode;
		if(cursor.prev == cursor) {
			cursor.prev = newNode;
			size++;
		}
		
		
		}
	}
	
	public T deleteCursor(){
		
		T value;
		size--;
		try {
			
			if(cursor.next == null){
			
				value = cursor.value;
				cursor = null;
				return value;
			} else {
				value = cursor.value;
				cursor.prev.next = cursor.next;
				cursor.next.prev = cursor.prev;
				cursor = cursor.next;
				return value;
				
			}
		} catch (NullPointerException e) {
			System.out.println("List Is Empty");
			System.exit(0);
			return null;
		}
		
			
	}
	
	public boolean isEmpty() {
		if(size == 0) {
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		// make sure the list is not empty
		if (cursor == null) {
			return "List is empty";
		}
		// declare and initialize a variable to store the result
		String result = "";
		// declare and initialize a variable to store the current node
		Node current = cursor;
		// loop that traverses the list until it arrives back to the cursor
		do {
			// concatenate the value of the current node to the result
			result = result + current.value + " ";
			// advance current node to its next node
			current = current.next;
		} while (current != cursor);
		return result;
	}
	
	// TODO replace remove after cursor with delete cursor method
	public class Node {
		private T value;
		private Node next;
		private Node prev;
		// constructor, accepts the value for this new node
		public Node(T v) {
			value = v;
			prev = null;
			next = null;
		}
		public Node(T v, Node n, Node p) {
			value = v;
			prev = p;
			next = n;
		}
	}
}
