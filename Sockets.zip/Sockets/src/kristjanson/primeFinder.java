package kristjanson;

public class primeFinder{

	int number;
	
	public primeFinder(int num) {
		
		number = num;
	}
	
	public boolean isPrime() {

		int i = 2;
		int c = 0;
		while (i <= number / 2) {
			if (number % i == 0) {
				c++;
				break;
			}
			i++;
		}
		if (c == 0) {
			return true;
		} else {
			return false;
		}
	}

	
}
