package kristjanson;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
public class Node {
	
	private static int Port = 6600;
	private static Socket s;
	private static int numPrimes = 0;
	public static void main(String[] args) {
		try {
			System.out.println("calling");
			s = new Socket("localHost", Port);
			System.out.println("Connected");
			numPrimes();
		} catch (IOException e) {
			System.out.println("node is issue");
			e.printStackTrace();
		}
	}

	public static boolean isPrime(int num) {
		
				if (num == 1 || num == 0) {
					return false;
				}
				// regular case: num != 1
				int i = 2;
				while (i <= Math.sqrt(num) && num % i != 0) {
					i++;
				}
				if (i <= Math.sqrt(num)) {
					return false;
				} else {
					return true;
				}
	}
	public static void numPrimes() {
		int numPrimes = 0;
		int startRange = 0;
		int endRange = 0;
		try {
			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
			startRange = (int) ois.readObject();
			endRange = (int) ois.readObject();
			for (int i = startRange; i <= endRange; i++) {
				if (isPrime(i)) {
					numPrimes++;
				}
			}
			oos.writeObject(numPrimes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}