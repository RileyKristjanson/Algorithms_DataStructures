package kristjanson;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Head {
	public static void main(String[] args) {
		int numNodes = 4;
		int currentNode = 0;
		int Port = 6600;
		Socket[] s = new Socket[numNodes];
		ServerSocket ss = null;
	
		try {
			ss = new ServerSocket(Port);
			
			while (currentNode < numNodes) {
				System.out.println("waiting for call");
				s[currentNode] = ss.accept();
				System.out.println("call accepted");
				currentNode++;
			}
			System.out.println("all nodes connected");
		
			Thread[] ths = new Thread[numNodes];
			int numPrimes = 0;
			int startRange = 1000;
			int endRange = 1000000;
			int[] primes = new int[numNodes];
			for (int i = 0; i < numNodes; i++) {
				int start = (endRange - startRange) / numNodes * i + startRange;
				int end = (endRange - startRange) / numNodes * (i + 1) - 1 + startRange;
				if (i == 3) {
					end++;
				}
				System.out.println("Thread " + i + " start: " + start + " end: " + end);
				runnable pT = new runnable(start, end, i, s[i], primes);
				Thread th = new Thread(pT);
				ths[i] = th;
				th.start();
			}
		
			for (int i = 0; i < numNodes; i++) {
				try {
					ths[i].join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		
			for (int i = 0; i < numNodes; i++) {
				numPrimes += primes[i];
			}
			System.out.println("Total Primes: " + numPrimes);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("server error");
		}
	}
}
