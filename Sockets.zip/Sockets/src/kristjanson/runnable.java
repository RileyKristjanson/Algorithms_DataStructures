package kristjanson;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
public class runnable implements Runnable {
	private int endRange;
	private int startRange;
	private int node;
	private Socket s;
	private int[] primes;
	
	public runnable(int startRange, int endRange, int node, Socket s, int[] primes) {
		// explicitly name variables in class
		this.endRange = endRange;
		this.startRange = startRange;
		this.node = node;
		this.s = s;
		this.primes = primes;
	}
	@Override
	public void run() {
//		primeThreads.numPrimes(node);
		try {
		
			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
			oos.writeObject(startRange);
			oos.writeObject(endRange);
			primes[node] = (int)ois.readObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}